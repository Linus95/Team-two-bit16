<?php
/*
	file:	admin/index.php
	desc:	Display the admin page if user is logged in
			checks that user is logged in and prevents 
			the page to be  saved any cache, proxy etc
*/
if(!empty($_GET['page'])) $page=$_GET['page'];else $page='';
session_start();
if(!isset($_SESSION['userID'])) header('location:../ourstories.php');
header('Cache-control:no-store,no-cache,must-revalidate');
?>
<!DOCTYPE html>
<html>
<head>


<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="">
<title>OurStories - Admin</title>
<!-- Bootstrap core CSS -->
<link href="./css/bootstrap.min.css" rel="stylesheet">
<!--jQuery-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="js/myscript.js"></script>
<!--	 Table that is responsive  -->

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<!-- Sidebar -->
<style>
	
	#mySidebar{
    background-color:#f5f5f5;
 
    color: black;
   
}
 
.w3-panel{
    background-color:#edeff2;
}

.w3-container{
	text-align: center;

}
.footer{
   background-image: url(../img/bg.jpg);
	background-color:#38393a;
	width: 100%;
  height: auto;
	padding-top:10px
	padding-bottom:-100%;

}
.body
{
 
  padding-bottom: 10%;
}

p{
	color: white;
}


h4 {
	text-align: center;
}
</style>
	<div class="w3-sidebar w3-bar-block w3-border-right" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-large">Close &times;</button>
  <a href="index.php?" class="w3-bar-item w3-button">Admin home </a>
  <a href="index.php?page=community" class="w3-bar-item w3-button"> <i class="fa fa-table"></i> Communities Table</a>
 <a href="index.php?page=company" class="w3-bar-item w3-button">  <i class="fa fa-university"></i> Companies Table</a>
   <a href="index.php?page=stories" class="w3-bar-item w3-button"> <i class="fa fa-book"></i> Stories Table </a>
     <a href="index.php?page=activity" class="w3-bar-item w3-button"> <i class="fa fa-bicycle"></i> Activities Table </a>
  <a href="index.php?page=users" class="w3-bar-item w3-button"> <i class="fa fa-users"></i> Users Table </a>
  <a href="index.php?page=chpwd" class="w3-bar-item w3-button"> <i class="fa fa-pencil-square"></i> Change password </a>
    <a href="logout.php" class="w3-bar-item w3-button">Logout </a>

</div>


<!-- Page Content -->
<div class="w3-teal">
  <button class="w3-button w3-teal w3-xlarge" onclick="w3_open()"> 
   <h2>Admin Panel </h2s></button>
  <div class="w3-container">
   <h4> Welcome to Admin Page </h4> 
  </div>
</div>
<script>
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}
</script>  


           <div class="w3-panel w3-card-4 width=device-width">

            <?php
			if($page=='chpwd') include('changepassword.php');
			if($page=='users') include('users.php');
			if($page=='editUser') include('editUser.php');
			if($page=='userFrm') include('userFrm.php');
			if($page=='community') include('community.php');
			if($page=='company') include('company.php');
			if($page=='stories') include('stories.php');
			if($page=='editStory') include('editStory.php');
			if($page=='editCompany') include('editCompany.php');
			if($page=='activity') include('activity.php');
			if($page=='editactivity') include('editactivity.php');
			if($page=='insertactivity') include('insertactivity.php');
			if($page=='deletestory') include('deletestory.php');
			if($page=='insertStory') include('insertStory.php');



		?>
</div>

<br>
<br>

   <!---- Footer ---->

<div class="footer">

  <div class="container">

 <div id="footer" class="footer">
     <div class="container">
         <div class="row">
             <div class="col-lg-4 col-md-4">
                 <h1><p>Support</p></h1>
                 <p><i class="fa fa-home" aria-hidden="true"></i> Kauppakatu 123, 95400 Tornio</p>
                 <p><i class="fa fa-envelope" aria-hidden="true"></i> ourstoriesteam2@gmail.com</p>
                 <p><i class="fa fa-phone" aria-hidden="true"></i> +358 098256428</p>
             </div>
              <br>
              <br>
             <div>
 
             <p><i class="fa fa-square-o" aria-hidden="true"></i> Privacy</p>
                 <p><i class="fa fa-square-o" aria-hidden="true"></i> Term&Condition</p>
             </div>   
             </div>
           </div>
         </div>
       </div>
           
              



</body>

  

 
</html> 



 

