

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>

			<?php
			
			if(!empty($_GET['mode'])) $mode=$_GET['mode'];else $mode='';
			//variables used in pager: $start and $nr_of_records defined here
			if(!empty($_GET['start'])) $start=$_GET['start'];else $start=0;
			$nr_of_records=5;  //display 5 records at list on every page
			//checkin, if on the firs page, start is always zero - even in previous
			if($start==0) $prev=$start;else $prev=$start-$nr_of_records;
			include('../db.php'); //use the database connection from parent folder
			//check the number of records from database table person
			$sql="SELECT count(*) as NrOfRecords FROM story";
			$result=$conn->query($sql);
			$row=$result->fetch_assoc();
			$TotalRecords=$row['NrOfRecords'];
			?>
			<h4>Stories</h4>
			<a href="index.php?page=stories&mode=add">Add new story</a>

			<?php
/* old */
	

		if($mode=='add'){
			echo '<form action="insertStory.php" method="post">
				  <tr>
					<td></td>
										<td></td>
					<td><input type="text" placeholder="StoryTitle" name="storyTitle" /></td>
					<td><input type="text" placeholder="storyType" name="storyType" /></td>
					<td><input type="text" placeholder="storyDescription" name="storyDescription" /></td>
					</td><td><input type="text" placeholder="storyKeywords" name="storyKeywords" /></td>
					</td><td><input type="text" placeholder="storyLink" name="storyLink" /></td>
										</td>
					 <td><input type="submit" value="Add" /></td>
					</td>
				  </tr>
				  <a href="index.php?page=stories" class="button"> close</a>

				  </form>';
		}


		
echo '<table class="table table-bordered table-striped"><tr><th>ID#</th><th>StoryTitle</th><th>StoryType</th><th>StoryDescription</th><th>StoryKeywords</th><th>StoryLink</th><th>Edit</th><th>Delete</th></tr>';





		include('../db.php');
		$sql="SELECT * FROM story ORDER BY storyTitle,storyType LIMIT $start,$nr_of_records";
		$result=$conn->query($sql);  //runs the query in database
		while($row=$result->fetch_assoc())
		{
				echo '<tr>';
			echo '<td>'.$row['storyID'].'</td>';
			echo '<td>'.$row['storyTitle'].'</td>';
			echo '<td>'.$row['storyType'].'</td>';
			echo '<td>'.$row['storyDescription'].'</td>';
			echo '<td>'.$row['storyKeywords'].'</td>';
			echo '<td><a href="'.$row['storyLink'].'" target="_new">'.$row['storyLink'].'</a></td>';
			echo '<td><a href="index.php?page=editStory&storyID='.$row['storyID'].'"><span class="glyphicon glyphicon-pencil"></span></a></td>';
			echo '<td><a href="index.php?page=deletestory&storyID='.$row['storyID'].'"><span class="glyphicon glyphicon-trash"></span></a></td>';
			echo '</tr>';
		
		}
		echo '</table>';

		$conn->close();
		?>
<ul class="pager">
<?php
	//check if in the first page
	if($start==0){
		echo '<li>Previous</li>';
	}else{
?>
  <li><a href="index.php?page=stories&start=<?php echo $prev?>">Previous</a></li>
<?php
	}
	//check if already in the last page
	$lastrecordnow=$start+$nr_of_records;
	if($lastrecordnow<$TotalRecords){
?>
  <li><a href="index.php?page=stories&start=<?php echo $start+$nr_of_records?>">Next</a></li>
  <li><a href="index.php?" class="button">Exit</a></li>
 </ul>
<?php
	}else echo '<li>Next</li>';
?>
 </ul>
 


<style>
	.button
	   {width: 5%;
      margin-right: 30px;
      margin-left: 30px;
      color: green;
      float: right;
    
  }
   form{
  	float: right;
  	color: green;

  }
 		
	
</style>

	





































