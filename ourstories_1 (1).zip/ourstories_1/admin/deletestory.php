<?php
/*
	file:	admin/deleteactivity.php
	desc:	Reads personID from get-list and deletes that record
			from database table person. Removes all placements from
			placement-table with that personID.
*/
if(!empty($_GET['storyID'])) $storyID=$_GET['storyID'];
else header('location:index.php?page=stories');
include('../db.php');
$sql="DELETE FROM story WHERE storyID=$storyID";
$conn->query($sql);
/*$sql="DELETE FROM placement WHERE companyID=$companyID"; */
$conn->query($sql);
header('location:index.php?page=stories');
?>