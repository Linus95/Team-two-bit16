
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>

<?php
/*
		file: 	ourstories_example/admin/users.php
		desc:	Displays the list of users in db
*/
include('../db.php'); //use the database connection from parent folder
$sql="SELECT level FROM user WHERE userID=".$_SESSION['userID'];
$result=$conn->query($sql);
if($result->num_rows>0){
	//Checking if admin user -> display links to edit/add users
	$row=$result->fetch_assoc();
	if($row['level']=='admin') $admin=true;else $admin=false;
}
?>
<h4>Users</h4>

<h5><a href="index.php?page=userFrm">Add user <span class="glyphicon glyphicon-user"></span></a></h5>
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th>UserID</th><th>Email</th><th>Firstname</th><th>Lastname</th><th>Phone</th><th>Level</th><th>Image</th><th>Update</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$sql="SELECT * FROM user ORDER BY lastname, firstname";
			$result=$conn->query($sql);  //runs the query in database
			while($row=$result->fetch_assoc()){
				echo '<tr>';
				echo '<td>'.$row['userID'].'</td>';
				echo '<td>'.$row['email'].'</td>';
				echo '<td>'.$row['firstname'].'</td>';
				echo '<td>'.$row['lastname'].'</td>';
				echo '<td>'.$row['phone'].'</td>';
				echo '<td>'.$row['level'].'</td>';
				echo '<td><img src="./images/'.$row['image'].'"  class="media-object" style="width:50px" /></td>';
				//edit links, if administrator
				if($admin OR(!$admin AND $_SESSION['userID']==$row['userID'] )){
					echo '<td><a href="index.php?page=editUser&userID='.$row['userID'].'"><span class="glyphicon glyphicon-pencil"></span></a></td>';
				}				
				echo '</tr>';
			}
			$conn->close();
		?>
	</tbody>
</table>


<style>
	.button
	   {width: 5%;
      margin-right: 30px;
      margin-left: 30px;
      color: green;
      float: right;
    
  }
 
		
		
	
</style>