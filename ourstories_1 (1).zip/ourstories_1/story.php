<?php
/*
	file: 	wines_ws.php
	desc:	Web service returning the list of all companies, in Tornio or Ylitornio from  company  database
			Result is returned as JSON
			Web service is available for all the users -> header
*/
//access control
header("Access-Control-Allow-Origin: * ");  //anybody, anywhere can access

//read the GET-field(s) from web service call
if(!empty($_GET['type'])) $type=$_GET['type']; else $type='all';

//database connection
include('db.php');

//character set changed to display all the characters
$conn->set_charset("utf8");

//sql-query
if($type=='all') $sql="SELECT * from story order by storyTitle,storyType";
//else $sql="SELECT * from story where story='$type' order by storyID";
else $sql="SELECT * from story where storyKeywords Like'$type%%' order by storyID";
$result=$conn->query($sql);
//create array
$storyarray=array(); //empty array defined
if($result->num_rows > 0){
	while($row=$result->fetch_assoc()){
		$storyarray[]=$row; //each row into array
	}
}
//return JSON encoded array
echo json_encode($storyarray);
$conn->close();
?>















